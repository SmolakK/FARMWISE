import pytest
# import os
# print(os.path.abspath(os.curdir))
# print(os.listdir())
# from my_statistics.my_statistics import momentum

#@pytest
def test_median():
    assert True

#@pytest
def test_mean():
    assert True